const TOKEN = "6140014934:AAH4N7SlRpsNPiKOMaTqR5UhwnpjfYYr6Gw";
const CHAT_ID = "-1001734639305";
const URI_API = `https://api.telegram.org/bot${ TOKEN }/sendMessage`;

document.getElementById('tg').addEventListener('submit', function(e){
    e.preventDefault();
    
    let message = `<b>Заявка с сайта!</b>\n`;
    message += `<b>Отправитель:</b> ${ this.name.value }\n`;
    message += `<b>Номер телефона:</b> ${ this.phone.value }`;

    axios.post(URI_API, {
        chat_id: CHAT_ID,
        parse_mode: `html`,
        text: message
    })
}) 